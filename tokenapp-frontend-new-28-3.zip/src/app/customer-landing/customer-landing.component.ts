import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { CustomerapiServiceService } from '../services/customerapi-service.service';
import { Router } from '@angular/router';
import { response } from 'express';

@Component({
  selector: 'app-customer-landing',
  imports: [CommonModule, FormsModule, HttpClientModule, ReactiveFormsModule],
  templateUrl: './customer-landing.component.html',
  styleUrl: './customer-landing.component.css',
})
export class CustomerLandingComponent  {
  customerTypeForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private customerapiServiceService: CustomerapiServiceService
  ) {
   
    this.customerTypeForm = this.fb.group({
      customerType: ['', Validators.required],
    });
  }

  customerTypeSubmit() {
    if (this.customerTypeForm.valid) {
      const selectedOption = this.customerTypeForm.value.customerType;
      console.log('Selected option is:', selectedOption);
      
      if(selectedOption == "Account Holder"){
        this.router.navigate(['account-holder'], {
        state: { customerType: selectedOption },
      });}
      if(selectedOption == "Non Account Holder"){
        this.router.navigate(['guest'], {
          state: { customerType: selectedOption },
        });
      }
    } else {
      console.log('Form is invalid. Please select an option.');
    }
  }
}
