import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerapiServiceService } from '../services/customerapi-service.service';
import { AdminapiServiceService } from '../services/adminapi-service.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-display-token-number',
  imports: [CommonModule],
  templateUrl: './display-token-number.component.html',
  styleUrl: './display-token-number.component.css',
})
export class DisplayTokenNumberComponent implements OnInit {
  constructor(
    private router: Router,
    private customerService: CustomerapiServiceService,
    private adminService: AdminapiServiceService
  ) {
    // setTimeout(() => {
    //   this.getCounters();
    // }, 1000);
  }

  ngOnInit(): void {
    this.getCounters();
  }
  getTokenList() {
    this.tokens=[]
    if (this.counters.length == 0) {
      alert('No counters available');
      return;
    }
    for (let i = 0; i < this.counters.length; i++) {
      this.getCurrentTokenNumber(this.counters[i].id);
    }
    this.tokenList=this.tokens
  }

  ngAfterViewInit() {

    // setTimeout(() => {
    //   this.getCounters();
    // }, 1000);
  }
  currentToken: any;
  counters: any = [];
  tokenList: any = [];
  tokens:any=[];
  getCurrentTokenNumber(counterNumber: any) {
    this.customerService

      .getCurrentTokenNumber(counterNumber)
      .subscribe((response) => {
        console.log(response);
        this.tokens.push(response);
        console.log(this.tokenList);
      });
  }

  getCounters() {
    // clear tokenlist
    this.adminService.getCountersShow().subscribe((response:any) => {
      console.log(response);
      this.counters = response;
      this.getTokenList();
    });
  }
}
