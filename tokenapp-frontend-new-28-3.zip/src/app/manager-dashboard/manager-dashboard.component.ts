import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import { CustomerapiServiceService } from '../services/customerapi-service.service';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-manager-dashboard',
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule,
  ],
  templateUrl: './manager-dashboard.component.html',
  styleUrl: './manager-dashboard.component.css',
})
export class ManagerDashboardComponent {
  // managerdashboardForm! : FormGroup;
  managerdashboard: any;
  constructor(
    private router: Router,
    private client: HttpClient,
    private fb: FormBuilder,
    private customerapiService: CustomerapiServiceService
  ) {}

  managerDashboardService() {}

  addService() {
    console.log('ok 🙋‍♀️');
    this.router.navigate(['manager-dashboard/manager-add-service']);
  }

  daySummary() {
    this.router.navigate(['manager-dashboard/manager-day-summary']);
  }

  getAnalysis() {}
  assignCounter() {
    this.router.navigate(['manager-dashboard/manager-assign-counter']);
  }
}
